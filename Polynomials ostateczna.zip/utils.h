#include <list>

#include "polynomial_part.h"

using namespace std;

bool should_remove (Polynomial_part part);
bool compare(Polynomial_part part1, Polynomial_part part2);
void check_for_given_x(list<Polynomial_part> p_list);
void print(list<Polynomial_part> list1);
int switcharoo();
