#include "utils.h"

int main(){
    switcharoo();
    return 0;
}

